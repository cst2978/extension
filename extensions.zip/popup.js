const TRANSPARENT_PIXEL_GIF =
  "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";

function buildListingUrl(listingAdId) {
  return `https://www.rvtrader.com/listing/${encodeURIComponent(listingAdId)}`;
}

function normalizeUrl(value, baseUrl) {
  if (!value) return null;
  try {
    return new URL(value, baseUrl).toString();
  } catch {
    return null;
  }
}

function getMetaContent(doc, selector) {
  const el = doc.querySelector(selector);
  const value = el?.getAttribute("content")?.trim();
  return value || null;
}

function formatPrice(value, currency = "USD") {
  if (value === null || value === undefined) return null;
  const raw = String(value).trim();
  if (!raw) return null;

  if (/^\d+(\.\d+)?$/.test(raw)) {
    const amount = Number(raw);
    if (!Number.isFinite(amount)) return raw;
    try {
      return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(amount);
    } catch {
      return `$${amount.toLocaleString("en-US")}`;
    }
  }

  return raw;
}

function extractFromJsonLd(json) {
  if (!json) return {};

  const items = [];
  if (Array.isArray(json)) items.push(...json);
  else if (Array.isArray(json["@graph"])) items.push(...json["@graph"]);
  else items.push(json);

  for (const item of items) {
    if (!item || typeof item !== "object") continue;

    const image = Array.isArray(item.image) ? item.image[0] : item.image;
    const offers = Array.isArray(item.offers) ? item.offers[0] : item.offers;
    const price = offers?.price ?? offers?.lowPrice ?? offers?.priceSpecification?.price;
    const priceCurrency = offers?.priceCurrency ?? offers?.priceSpecification?.priceCurrency;

    if (image || price) {
      return { image, price, priceCurrency };
    }
  }

  return {};
}

function parseListingDetailsFromHtml(html, listingUrl) {
  const doc = new DOMParser().parseFromString(html, "text/html");

  const metaImage =
    getMetaContent(doc, 'meta[property="og:image:secure_url"]') ||
    getMetaContent(doc, 'meta[property="og:image"]') ||
    getMetaContent(doc, 'meta[name="twitter:image"]');

  const metaPrice =
    getMetaContent(doc, 'meta[property="product:price:amount"]') ||
    getMetaContent(doc, 'meta[property="og:price:amount"]') ||
    getMetaContent(doc, 'meta[property="og:price"]');

  const metaCurrency =
    getMetaContent(doc, 'meta[property="product:price:currency"]') ||
    getMetaContent(doc, 'meta[property="og:price:currency"]');

  let jsonLdImage = null;
  let jsonLdPrice = null;
  let jsonLdCurrency = null;

  const jsonLdScripts = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
  for (const script of jsonLdScripts) {
    const text = script.textContent?.trim();
    if (!text) continue;
    try {
      const json = JSON.parse(text);
      const { image, price, priceCurrency } = extractFromJsonLd(json);
      jsonLdImage ||= image || null;
      jsonLdPrice ||= price ?? null;
      jsonLdCurrency ||= priceCurrency || null;
      if (jsonLdImage && jsonLdPrice) break;
    } catch {
      // Ignore invalid JSON-LD blocks.
    }
  }

  const imageUrl = normalizeUrl(metaImage || jsonLdImage, listingUrl);
  const currency = metaCurrency || jsonLdCurrency || "USD";
  const priceText = formatPrice(metaPrice ?? jsonLdPrice, currency);

  return { imageUrl, priceText };
}

async function fetchListingDetails(listingAdId) {
  const listingUrl = buildListingUrl(listingAdId);
  const response = await fetch(listingUrl, { headers: { Accept: "text/html" } });
  if (!response.ok) {
    throw new Error(`Listing fetch returned status ${response.status}`);
  }
  const html = await response.text();
  return parseListingDetailsFromHtml(html, listingUrl);
}

function renderRecommendations(recommendations) {
  const container = document.getElementById("report");
  container.innerHTML = "<strong>Recommended Listings:</strong>";

  if (!recommendations || recommendations.length === 0) {
    container.innerHTML += "<p>No recommendations found.</p>";
    return;
  }

  const topFive = recommendations.slice(0, 5);
  const list = document.createElement("ul");
  list.className = "rec-list";

  topFive.forEach((rec, index) => {
    const id = rec.listing_ad_id;
    const listingUrl = buildListingUrl(id);

    const li = document.createElement("li");
    li.className = "rec-item";

    const card = document.createElement("a");
    card.className = "rec-card";
    card.href = listingUrl;
    card.target = "_blank";
    card.rel = "noopener noreferrer";

    const img = document.createElement("img");
    img.className = "rec-thumb placeholder";
    img.alt = `Listing ${id}`;
    img.src = TRANSPARENT_PIXEL_GIF;
    img.loading = "lazy";

    const info = document.createElement("div");
    info.className = "rec-info";

    const price = document.createElement("div");
    price.className = "rec-price";
    price.textContent = "Loading price...";

    const meta = document.createElement("div");
    meta.className = "rec-meta";
    meta.textContent = `${index + 1}. Ad ID: ${id}`;

    info.appendChild(price);
    info.appendChild(meta);
    card.appendChild(img);
    card.appendChild(info);
    li.appendChild(card);
    list.appendChild(li);

    void (async () => {
      try {
        const details = await fetchListingDetails(id);
        price.textContent = details.priceText || "Price unavailable";
        if (details.imageUrl) {
          img.src = details.imageUrl;
          img.classList.remove("placeholder");
        } else {
          img.classList.add("placeholder");
        }
      } catch (e) {
        console.warn(`Failed to fetch details for ${id}`, e);
        price.textContent = "Price unavailable";
      }
    })();
  });

  container.appendChild(list);
}

function showError(message) {
  document.getElementById("report").innerHTML = `<p class="error">${message}</p>`;
}

const FALLBACK_RECOMMENDATIONS = [
  { listing_ad_id: 5037450439 },
  { listing_ad_id: 5037527156 },
  { listing_ad_id: 5037081635 },
  { listing_ad_id: 5035375144 },
  { listing_ad_id: 5036204391 },
  { listing_ad_id: 5037740751 },
  { listing_ad_id: 5036204610 },
  { listing_ad_id: 5037305774 },
  { listing_ad_id: 5038011392 },
  { listing_ad_id: 5038005674 },
  { listing_ad_id: 5031756205 },
  { listing_ad_id: 5036959067 },
  { listing_ad_id: 5038073185 },
  { listing_ad_id: 5033271342 },
  { listing_ad_id: 5037973504 },
  { listing_ad_id: 5037941980 },
  { listing_ad_id: 5038279026 },
  { listing_ad_id: 5038422809 },
  { listing_ad_id: 5038525755 },
  { listing_ad_id: 5038525750 },
];

async function getListingContext(tabId) {
  const [injected] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const extractAdId = () => {
        const match = location.href.match(/listing\/[^/]*-(\d+)/);
        return match ? Number(match[1]) : null;
      };

      const tryFindZip = () => {
        const scripts = Array.from(document.querySelectorAll('script[type="application/json"], script'));
        for (const s of scripts) {
          const text = s.textContent || "";
          if (!/\b\d{5}\b/.test(text)) continue;
          try {
            const json = JSON.parse(text);
            const asString = JSON.stringify(json);
            const zip = asString.match(/\b\d{5}\b/);
            if (zip) return Number(zip[0]);
          } catch (e) {
            const zip = text.match(/\b\d{5}\b/);
            if (zip) return Number(zip[0]);
          }
        }
        const bodyText = document.body?.innerText || "";
        const fallbackZip = bodyText.match(/\b\d{5}\b/);
        return fallbackZip ? Number(fallbackZip[0]) : null;
      };

      return {
        listing_ad_id: extractAdId(),
        user_zip: tryFindZip(),
      };
    },
  });

  return injected?.result || {};
}

async function loadRecommendations() {
  const container = document.getElementById("report");
  container.textContent = "Loading...";

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      showError("No active tab found.");
      return;
    }

    const { listing_ad_id, user_zip } = await getListingContext(tab.id);

    if (!listing_ad_id || !user_zip) {
      showError("Could not extract ad ID or ZIP from this page.");
      return;
    }

    const payload = {
      listing_ad_id,
      user_zip,
      radius_mi: 500,
      k: 20,
    };

    const response = await fetch("https://dev.apis.datascience.tilabs.io/recommendation_engine", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (response.status === 401 || response.status === 403) {
      console.warn("Unauthorized: unable to access recommendations API. Using fallback recommendations.");
      renderRecommendations(FALLBACK_RECOMMENDATIONS);
      return;
    }

    if (!response.ok) {
      throw new Error(`API returned status ${response.status}`);
    }

    const data = await response.json();
    if (!Array.isArray(data.recommendations) || data.recommendations.length === 0) {
      console.warn("API returned no recommendations. Using fallback recommendations.");
      renderRecommendations(FALLBACK_RECOMMENDATIONS);
      return;
    }

    renderRecommendations(data.recommendations);
  } catch (error) {
    console.error(error);
    console.warn("Failed to load recommendations from API. Using fallback recommendations.");
    renderRecommendations(FALLBACK_RECOMMENDATIONS);
  }
}

loadRecommendations();
